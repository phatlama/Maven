package Maphefo.example.Maphefo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaphefoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaphefoApplication.class, args);
	}

}
