package Maphefo.example.Maphefo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaphefoApplicationTests {

	@Test
	void contextLoads() {
	}

}
